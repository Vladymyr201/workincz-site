import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.12.4/firebase-app.js';
import { 
    getAuth, 
    signInWithPopup, 
    GoogleAuthProvider, 
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    onAuthStateChanged, 
    signOut 
} from 'https://www.gstatic.com/firebasejs/10.12.4/firebase-auth.js';

// 1. ПРАВИЛЬНАЯ конфигурация из Project Settings
const firebaseConfig = {
  apiKey: "AIzaSyBQBIE0lphKrKyq40dGmv3zDACVnJL90Z0",  // ← ИСПРАВЛЕНО на правильный
  authDomain: "workincz-759c7.firebaseapp.com",
  databaseURL: "https://workincz-759c7-default-rtdb.europe-west1.fil",
  projectId: "workincz-759c7",
  storageBucket: "workincz-759c7.firebasestorage.app",
  messagingSenderId: "670842817143",
  appId: "1:670842817143:web:d8998634da78318e9f1472",
  measurementId: "G-PB27XT0CT0"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

// 2. Защита dashboard.html
onAuthStateChanged(auth, user => {
  const onDashboard = location.pathname.endsWith('/dashboard.html');
  if (!user && onDashboard) {
    location.replace('/');      // нет токена → на логин
  }
  if (user && !onDashboard && location.pathname === '/') {
    location.replace('/dashboard.html'); // есть токен → на дашборд
  }
});

// 3. Функции аутентификации
export const login = () => signInWithPopup(auth, provider).catch(console.error);
export const logout = () => signOut(auth).then(() => location.replace('/'));

// 4. Email/Password функции
export const registerWithEmail = (email, password) => 
  createUserWithEmailAndPassword(auth, email, password);

export const loginWithEmail = (email, password) => 
  signInWithEmailAndPassword(auth, email, password);

// 5. Получить текущего пользователя
export const getCurrentUser = () => auth.currentUser;

// 6. Проверить, авторизован ли пользователь
export const isAuthenticated = () => !!auth.currentUser;