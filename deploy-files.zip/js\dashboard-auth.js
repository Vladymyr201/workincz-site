// 🎭 DashboardAuth - авторизация для дашбордов (v2.0)
// Поддержка Firebase Anonymous Auth и демо-пользователей

class DashboardAuth {
  constructor() {
    this.isHandled = false;
    this.isInitialized = false;
    
    console.log('🎭 DashboardAuth v2.0 инициализирован');
    
    // Автоматическая инициализация
    this.init();
  }

  async init() {
    try {
      // Ждем инициализации AuthManager
      let attempts = 0;
      const maxAttempts = 50;
      
      while (!window.authManager?.isInitialized && attempts < maxAttempts) {
        await new Promise(resolve => setTimeout(resolve, 100));
        attempts++;
      }
      
      if (!window.authManager?.isInitialized) {
        console.warn('⚠️ AuthManager не инициализирован, DashboardAuth работает в ограниченном режиме');
      }
      
      this.isInitialized = true;
      console.log('🎭 DashboardAuth инициализирован');
      
      // Запускаем проверку авторизации
      this.setupAuthCheck();
      
    } catch (error) {
      console.error('❌ Ошибка инициализации DashboardAuth:', error);
    }
  }

  setupAuthCheck() {
    if (!this.isInitialized) {
      console.log('⏳ DashboardAuth еще не инициализирован, откладываю проверку');
      setTimeout(() => this.setupAuthCheck(), 500);
      return;
    }

    console.log('🎭 DashboardAuth: настройка проверки авторизации');

    // Подписываемся на изменения состояния авторизации
    window.authManager.subscribe({
      onLoggedIn: (user, profile) => {
        console.log('🎭 DashboardAuth: пользователь авторизован', {
          uid: user?.uid,
          role: profile?.role,
          isDemo: profile?.isDemoAccount
        });
        
        this.handleAuthenticatedUser(user, profile);
      },
      onLoggedOut: () => {
        console.log('🎭 DashboardAuth: пользователь вышел');
        this.handleUnauthenticatedUser();
      },
      timeout: 5000
    });

    // Fallback проверка для случаев, когда AuthManager еще не готов
    setTimeout(() => {
      this.fallbackAuthCheck();
    }, 2000);
  }

  handleAuthenticatedUser(user, profile) {
    if (this.isHandled) {
      console.log('🎭 DashboardAuth: пользователь уже обработан');
      return;
    }

    console.log('🎭 DashboardAuth: обработка авторизованного пользователя');

    try {
      // Определяем роль пользователя
      const role = this.determineUserRole(user, profile);
      
      // Обновляем UI дашборда
      this.updateDashboardUI(user, profile, role);
      
      // Устанавливаем флаг обработки
      this.isHandled = true;
      
      console.log('🎭 DashboardAuth: пользователь успешно обработан');
      
    } catch (error) {
      console.error('❌ Ошибка обработки авторизованного пользователя:', error);
      this.handleError(error);
    }
  }

  determineUserRole(user, profile) {
    // Приоритет: профиль из Firestore > URL параметры > определение по email
    if (profile?.role) {
      return profile.role;
    }
    
    // Проверяем URL параметры
    const urlParams = new URLSearchParams(window.location.search);
    const urlRole = urlParams.get('role');
    if (urlRole) {
      return urlRole;
    }
    
    // Определяем по email (для обратной совместимости)
    if (user.email) {
      if (user.email.includes('candidate')) return 'candidate';
      if (user.email.includes('client')) return 'client';
      if (user.email.includes('agency')) return 'agency';
      if (user.email.includes('admin')) return 'admin';
    }
    
    // Для анонимных пользователей определяем роль по URL
    if (user.isAnonymous) {
      const currentPath = window.location.pathname;
      if (currentPath.includes('employer-dashboard')) return 'client';
      if (currentPath.includes('agency-dashboard')) return 'agency';
      if (currentPath.includes('admin-dashboard')) return 'admin';
      return 'candidate'; // По умолчанию
    }
    
    return 'candidate'; // Роль по умолчанию
  }

  updateDashboardUI(user, profile, role) {
    console.log('🎭 DashboardAuth: обновление UI дашборда', { role, isDemo: profile?.isDemoAccount });

    // Скрываем сообщение о загрузке
    this.hideLoadingMessage();

    // Устанавливаем глобальные переменные
    window.currentUser = user;
    window.currentUserProfile = profile;
    window.currentUserRole = role;
    window.isDemoUser = profile?.isDemoAccount || false;
    window.isAnonymousUser = user?.isAnonymous || false;

    // Обновляем классы body
    document.body.classList.remove('role-candidate', 'role-client', 'role-agency', 'role-admin');
    document.body.classList.add(`role-${role}`);

    // Показываем индикатор демо-режима если нужно
    if (profile?.isDemoAccount) {
      this.showDemoIndicator();
    }

    // Обновляем навигацию
    this.updateNavigation(role);

    // Обновляем контент дашборда
    this.updateDashboardContent(role, profile);

    // Уведомляем другие компоненты
    const event = new CustomEvent('dashboardReady', { 
      detail: { user, profile, role } 
    });
    document.dispatchEvent(event);

    console.log('🎭 DashboardAuth: UI дашборда обновлен');
  }

  updateNavigation(role) {
    // Обновляем навигацию в зависимости от роли
    const navItems = document.querySelectorAll('[data-role-nav]');
    navItems.forEach(item => {
      const requiredRole = item.getAttribute('data-role-nav');
      if (requiredRole === role || requiredRole === 'all') {
        item.style.display = 'block';
      } else {
        item.style.display = 'none';
      }
    });

    // Обновляем активную вкладку
    const currentPath = window.location.pathname;
    const activeNavItem = document.querySelector(`[data-nav-path="${currentPath}"]`);
    if (activeNavItem) {
      document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
      activeNavItem.classList.add('active');
    }
  }

  updateDashboardContent(role, profile) {
    // Обновляем контент дашборда
    const contentSections = document.querySelectorAll('[data-role-content]');
    contentSections.forEach(section => {
      const sectionRole = section.getAttribute('data-role-content');
      if (sectionRole === role || sectionRole === 'all') {
        section.style.display = 'block';
      } else {
        section.style.display = 'none';
      }
    });

    // Загружаем данные пользователя
    this.loadUserData(role, profile);
  }

  loadUserData(role, profile) {
    // Загружаем данные в зависимости от роли
    if (profile?.isDemoAccount) {
      this.loadDemoData(role, profile);
    } else {
      this.loadRealUserData(role, profile);
    }
  }

  loadDemoData(role, profile) {
    console.log('🎭 DashboardAuth: загрузка демо-данных', { role, profile });

    // Обновляем статистику
    if (profile.stats) {
      this.updateStats(profile.stats);
    }

    // Обновляем информацию профиля
    this.updateProfileInfo(profile);

    // Показываем демо-уведомление
    this.showDemoNotification();
  }

  loadRealUserData(role, profile) {
    console.log('🎭 DashboardAuth: загрузка реальных данных пользователя', { role, profile });

    // Здесь можно добавить загрузку реальных данных из Firestore
    // Пока просто обновляем базовую информацию
    if (profile) {
      this.updateProfileInfo(profile);
    }
  }

  updateStats(stats) {
    // Обновляем статистику на дашборде
    Object.entries(stats).forEach(([key, value]) => {
      const statElement = document.querySelector(`[data-stat="${key}"]`);
      if (statElement) {
        statElement.textContent = value;
      }
    });
  }

  updateProfileInfo(profile) {
    // Обновляем информацию профиля
    const nameElement = document.querySelector('[data-profile-name]');
    if (nameElement && profile.name) {
      nameElement.textContent = profile.name;
    }

    const roleElement = document.querySelector('[data-profile-role]');
    if (roleElement && profile.role) {
      roleElement.textContent = this.getRoleDisplayName(profile.role);
    }
  }

  showDemoIndicator() {
    // Показываем индикатор демо-режима
    const existingIndicator = document.querySelector('.demo-indicator');
    if (existingIndicator) {
      existingIndicator.remove();
    }

    const indicator = document.createElement('div');
    indicator.className = 'demo-indicator fixed top-4 left-4 bg-blue-500 text-white px-4 py-2 rounded-lg shadow-lg z-50 flex items-center gap-2';
    indicator.innerHTML = `
      <i class="ri-test-tube-line"></i>
      <span>Demo режим</span>
    `;

    document.body.appendChild(indicator);

    // Убираем через 10 секунд
    setTimeout(() => {
      if (indicator.parentElement) {
        indicator.remove();
      }
    }, 10000);
  }

  showDemoNotification() {
    // Показываем уведомление о демо-режиме
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-blue-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 flex items-center gap-3';
    notification.innerHTML = `
      <i class="ri-information-line text-xl"></i>
      <span>Вы находитесь в демо-режиме. Данные не сохраняются.</span>
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
      if (notification.parentElement) {
        notification.remove();
      }
    }, 5000);
  }

  handleUnauthenticatedUser() {
    console.log('🎭 DashboardAuth: пользователь не авторизован, проверяем демо и dev-пользователей');

    // Проверяем демо и dev-пользователей по URL параметрам
    const urlParams = new URLSearchParams(window.location.search);
    const isDemo = urlParams.get('demo') === 'true';
    const isDev = urlParams.get('dev') === 'true';
    const role = urlParams.get('role');
    
    if ((isDemo || isDev) && role) {
      const userType = isDemo ? 'демо' : 'dev';
      console.log(`🎭 DashboardAuth: обнаружен ${userType}-пользователь с ролью: ${role}`);
      
      // Создаем профиль
      const profile = {
        role: role,
        isDemoAccount: isDemo,
        isDevAccount: isDev,
        name: `${isDemo ? 'Демо' : 'Dev'} ${this.getRoleDisplayName(role)}`,
        email: `${isDemo ? 'demo' : 'dev'}-${role}@workincz.cz`,
        createdAt: new Date().toISOString()
      };
      
      // Обрабатываем как авторизованного пользователя
      this.handleAuthenticatedUser(null, profile);
      return;
    }

    console.log('🎭 DashboardAuth: пользователь не авторизован, перенаправление');

    // Показываем сообщение о необходимости авторизации
    this.showAuthRequiredMessage();

    // Перенаправляем на главную страницу через 3 секунды
    setTimeout(() => {
      window.location.href = '/';
    }, 3000);
  }

  showAuthRequiredMessage() {
    const message = document.createElement('div');
    message.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    message.innerHTML = `
      <div class="bg-white rounded-lg p-6 max-w-md mx-4 text-center">
        <i class="ri-lock-line text-4xl text-red-500 mb-4"></i>
        <h3 class="text-xl font-semibold mb-2">Требуется авторизация</h3>
        <p class="text-gray-600 mb-4">Для доступа к дашборду необходимо войти в систему.</p>
        <div class="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
      </div>
    `;

    document.body.appendChild(message);
  }

  hideLoadingMessage() {
    const loadingMessage = document.querySelector('.loading-message');
    if (loadingMessage) {
      loadingMessage.remove();
    }
  }

  fallbackAuthCheck() {
    // Fallback проверка для случаев, когда AuthManager не сработал
    if (this.isHandled) {
      return;
    }

    console.log('🎭 DashboardAuth: fallback проверка авторизации');

    const user = window.authManager?.getCurrentUser();
    const profile = window.authManager?.getCurrentProfile();

    if (user) {
      console.log('🎭 DashboardAuth: fallback - пользователь найден');
      this.handleAuthenticatedUser(user, profile);
    } else {
      console.log('🎭 DashboardAuth: fallback - пользователь не найден');
      this.handleUnauthenticatedUser();
    }
  }

  handleError(error) {
    console.error('❌ DashboardAuth ошибка:', error);
    
    // Показываем сообщение об ошибке
    const errorMessage = document.createElement('div');
    errorMessage.className = 'fixed top-4 right-4 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg z-50';
    errorMessage.innerHTML = `
      <i class="ri-error-warning-line text-xl"></i>
      <span>Ошибка загрузки дашборда: ${error.message}</span>
    `;

    document.body.appendChild(errorMessage);

    setTimeout(() => {
      if (errorMessage.parentElement) {
        errorMessage.remove();
      }
    }, 5000);
  }

  getRoleDisplayName(role) {
    const roleNames = {
      candidate: 'Соискатель',
      client: 'Работодатель',
      agency: 'Агентство',
      admin: 'Администратор'
    };
    return roleNames[role] || 'Пользователь';
  }
}

// Инициализация при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
  window.dashboardAuth = new DashboardAuth();
});

// Экспорт для использования в других скриптах
if (typeof module !== 'undefined' && module.exports) {
  module.exports = DashboardAuth;
} 