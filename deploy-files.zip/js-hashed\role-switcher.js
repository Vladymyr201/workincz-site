// 🎭 Role Switcher - UI компонент для переключения тестовых ролей
// Простой и удобный интерфейс для тестирования

class RoleSwitcher {
  constructor() {
    this.isVisible = false;
    this.container = null;
    this.testAccounts = [
      {
        role: 'candidate',
        email: 'test-candidate@workclick.cz',
        password: 'test1234',
        displayName: 'Тестовый Соискатель',
        label: '🔹 Соискатель',
        color: 'bg-blue-500 hover:bg-blue-600'
      },
      {
        role: 'employer', 
        email: 'test-employer@workclick.cz',
        password: 'test1234',
        displayName: 'Тестовый Работодатель',
        label: '🟢 Работодатель',
        color: 'bg-green-500 hover:bg-green-600'
      },
      {
        role: 'agency',
        email: 'test-agency@workclick.cz', 
        password: 'test1234',
        displayName: 'Тестовое Агентство',
        label: '🟡 Агентство',
        color: 'bg-yellow-500 hover:bg-yellow-600'
      },
      {
        role: 'admin',
        email: 'test-admin@workclick.cz',
        password: 'test1234', 
        displayName: 'Тестовый Админ',
        label: '🔴 Админ',
        color: 'bg-red-500 hover:bg-red-600'
      }
    ];
    
    this.init();
  }

  // Инициализация компонента
  init() {
    this.createUI();
    this.bindEvents();
    this.showToggleButton();
    
    console.log('[RoleSwitcher] Компонент инициализирован');
  }

  // Создание UI элементов
  createUI() {
    // Создаём контейнер для переключателя ролей
    this.container = document.createElement('div');
    this.container.id = 'role-switcher';
    this.container.className = 'fixed bottom-4 left-4 z-50 transition-all duration-300';
    this.container.style.display = 'none';
    
    // Создаём панель с ролями
    const panel = document.createElement('div');
    panel.className = 'bg-white rounded-lg shadow-xl border border-gray-200 p-4 mb-2';
    panel.style.minWidth = '200px';
    
    // Заголовок
    const header = document.createElement('div');
    header.className = 'text-sm font-semibold text-gray-700 mb-3 pb-2 border-b border-gray-200';
    header.textContent = '🎭 Переключение ролей';
    
    // Список ролей
    const roleList = document.createElement('div');
    roleList.className = 'space-y-2';
    
    this.testAccounts.forEach(account => {
      const button = document.createElement('button');
      button.className = `w-full text-left px-3 py-2 rounded text-sm font-medium text-white transition-colors ${account.color}`;
      button.textContent = account.label;
      button.dataset.email = account.email;
      button.dataset.role = account.role;
      
      roleList.appendChild(button);
    });
    
    // Кнопка выхода
    const logoutButton = document.createElement('button');
    logoutButton.className = 'w-full text-left px-3 py-2 rounded text-sm font-medium bg-gray-500 hover:bg-gray-600 text-white transition-colors mt-3';
    logoutButton.textContent = '🚪 Выйти';
    logoutButton.id = 'logout-button';
    
    // Собираем панель
    panel.appendChild(header);
    panel.appendChild(roleList);
    panel.appendChild(logoutButton);
    
    // Кнопка переключения (круглая)
    const toggleButton = document.createElement('button');
    toggleButton.id = 'role-switcher-toggle';
    toggleButton.className = 'w-12 h-12 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full shadow-lg transition-all duration-300 flex items-center justify-center text-lg';
    toggleButton.innerHTML = '🎭';
    toggleButton.title = 'Переключить роль';
    
    // Добавляем элементы в контейнер
    this.container.appendChild(panel);
    this.container.appendChild(toggleButton);
    
    // Добавляем в body
    document.body.appendChild(this.container);
  }

  // Привязка событий
  bindEvents() {
    // Кнопка переключения
    const toggleButton = document.getElementById('role-switcher-toggle');
    if (toggleButton) {
      toggleButton.addEventListener('click', () => this.toggle());
    }
    
    // Кнопки ролей
    this.container.addEventListener('click', (event) => {
      if (event.target.dataset.email) {
        this.switchRole(event.target.dataset.email);
      } else if (event.target.id === 'logout-button') {
        this.logout();
      }
    });
    
    // Закрытие по клику вне панели
    document.addEventListener('click', (event) => {
      if (!this.container.contains(event.target) && this.isVisible) {
        this.hide();
      }
    });
  }

  // Показать/скрыть панель
  toggle() {
    if (this.isVisible) {
      this.hide();
    } else {
      this.show();
    }
  }

  // Показать панель
  show() {
    this.container.style.display = 'block';
    this.isVisible = true;
    
    // Анимация появления
    setTimeout(() => {
      this.container.style.transform = 'translateY(0) scale(1)';
      this.container.style.opacity = '1';
    }, 10);
  }

  // Скрыть панель
  hide() {
    this.container.style.transform = 'translateY(10px) scale(0.95)';
    this.container.style.opacity = '0';
    
    setTimeout(() => {
      this.container.style.display = 'none';
      this.isVisible = false;
    }, 300);
  }

  // Переключение роли
  async switchRole(email) {
    try {
      console.log(`[RoleSwitcher] Переключение на: ${email}`);
      
      // Показываем индикатор загрузки
      this.showLoading();
      
      // Используем TestAuthSystem для переключения
      if (window.testAuthSystem) {
        await window.testAuthSystem.switchRole(email);
      } else {
        console.error('[RoleSwitcher] TestAuthSystem не найден');
      }
      
    } catch (error) {
      console.error('[RoleSwitcher] Ошибка переключения роли:', error);
      this.showError('Ошибка переключения роли');
    }
  }

  // Выход
  async logout() {
    try {
      console.log('[RoleSwitcher] Выход из системы');
      
      if (window.testAuthSystem) {
        await window.testAuthSystem.signOut();
        window.location.href = '/';
      }
    } catch (error) {
      console.error('[RoleSwitcher] Ошибка выхода:', error);
    }
  }

  // Показать индикатор загрузки
  showLoading() {
    const toggleButton = document.getElementById('role-switcher-toggle');
    if (toggleButton) {
      toggleButton.innerHTML = '⏳';
      toggleButton.disabled = true;
      
      // Восстанавливаем через 2 секунды
      setTimeout(() => {
        toggleButton.innerHTML = '🎭';
        toggleButton.disabled = false;
      }, 2000);
    }
  }

  // Показать ошибку
  showError(message) {
    // Создаём временное уведомление об ошибке
    const notification = document.createElement('div');
    notification.className = 'fixed top-4 right-4 bg-red-500 text-white px-4 py-2 rounded shadow-lg z-50';
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Удаляем через 3 секунды
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 3000);
  }

  // Показать кнопку переключения (только на нужных страницах)
  showToggleButton() {
    const allowedPages = ['/', '/dashboard.html', '/employer-dashboard.html', '/agency-dashboard.html', '/admin-dashboard.html', '/test-role-switcher.html'];
    const currentPage = window.location.pathname;
    
    if (allowedPages.includes(currentPage)) {
      this.container.style.display = 'block';
    }
  }

  // Обновить информацию о текущем пользователе
  updateCurrentUserInfo() {
    if (window.testAuthSystem && window.testAuthSystem.getCurrentUser()) {
      const user = window.testAuthSystem.getCurrentUser();
      const profile = window.testAuthSystem.getCurrentProfile();
      
      // Обновляем заголовок панели
      const header = this.container.querySelector('.text-sm.font-semibold');
      if (header) {
        header.textContent = `🎭 ${profile?.name || user.email}`;
      }
    }
  }
}

// Создаём глобальный экземпляр
window.roleSwitcher = new RoleSwitcher(); 